Сюда добавьте ваши звуковые файлы.

Структура должна быть такой:

docs/
  index.html
  Verbs.html
  Declension.html
  audio/
    ваши_файлы.mp3

После загрузки в GitHub Pages звуковые файлы должны лежать именно внутри папки docs/audio,
если HTML-страницы опубликованы из папки docs.
