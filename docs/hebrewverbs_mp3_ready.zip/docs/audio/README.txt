Папка для звуковых файлов.

Положите сюда mp3-файлы с такими именами:
- shalom.mp3
- kara.mp3
- ivrit.mp3
- sefer.mp3

Структура должна быть такой:
docs/
  index.html
  Verbs.html
  Declension.html
  audio/
    shalom.mp3
    kara.mp3
    ivrit.mp3
    sefer.mp3
